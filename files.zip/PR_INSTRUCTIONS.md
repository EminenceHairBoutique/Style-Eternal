# How to Create This Pull Request

## Option 1: Use the Patch File (Fastest)

1. Download the `brand-cleanup.patch` file
2. In your local clone of the repo, run:
   ```bash
   git checkout -b fix/brand-cleanup-and-critical-bugs
   git apply brand-cleanup.patch
   git add -A
   git commit -m "fix: brand cleanup, email bug fix, SEO domain correction"
   git push origin fix/brand-cleanup-and-critical-bugs
   ```
3. Go to GitHub → Pull Requests → New Pull Request
4. Set base: `main`, compare: `fix/brand-cleanup-and-critical-bugs`
5. Paste the PR description below

## Option 2: Use GitHub Copilot (Agent Mode)

Open GitHub Copilot in the repo and paste this prompt:

> Apply the following changes across the codebase:
>
> 1. **Fix critical bug in `lib/email.js`**: Line 254 references `${attachmentLine}` which is undefined. Replace with `${uploadsHtml}` (the variable defined on line 186).
>
> 2. **Replace all email addresses**: Change every occurrence of `eminenceluxuryhair.com` to `styleeternal.com` across all files. This includes `from:`, `reply_to:`, and `to:` fields in `lib/email.js`.
>
> 3. **Replace all brand name references**: Change "Eminence Hair", "Eminence Hair Boutique", "Eminence Concierge" to "Style Eternal", "Style Eternal", "Style Eternal Concierge" respectively. Check: `lib/email.js`, `scripts/generate-static-seo.mjs`, `scripts/audit-products.mjs`, `LAUNCH_CHECKLIST.md`, `OPTION_A_NOTES.md`, `REPO_MAP.md`, `README.md`.
>
> 4. **Fix `scripts/generate-static-seo.mjs`**:
>    - Change `SITE_NAME` to `"Style Eternal"`
>    - Change default `SITE_URL` to `"https://www.styleeternal.com"`
>    - Change `DEFAULT_OG_IMAGE` to use `se_og_banner.jpg`
>    - Replace all route descriptions that reference wigs, bundles, closures, hair, HD lace, Cambodian, Myanmar, cranial prosthesis with streetwear-appropriate descriptions (tees, hoodies, outerwear, bottoms, headwear, accessories)
>    - Remove routes that don't exist in the streetwear app: `/shop/wigs`, `/shop/bundles`, `/shop/closures`, `/medical-hair`, `/care`, `/authenticity`, `/atelier/try-on`, `/private-consult`, `/custom-orders`, `/custom-atelier`, `/gallery`, `/collections/fw-2025`
>    - Add missing routes: `/drops`, `/editorial`, `/community`, and category routes `/shop/tees`, `/shop/hoodies`, `/shop/outerwear`, `/shop/bottoms`, `/shop/headwear`, `/shop/accessories`
>    - Replace `COLLECTION_META` with entries matching actual collections: north-ward, iron-bound, essentials, legacy, graphics, love-never-dies, archive
>
> 5. **Fix `package.json`**: Change `"name": "eminence-hair"` to `"name": "style-eternal"`
>
> 6. **Fix e2e tests**:
>    - `tests/e2e/home.spec.js`: Change title assertion from `/Eminence/i` to `/Style Eternal/i`, change localStorage key from `"eminence_referral"` to `"se_referral"`
>    - `tests/e2e/checkout.spec.js`: Change `"eminence_referral"` to `"se_referral"`
>
> 7. **Rewrite `.github/copilot-instructions.md`**: Replace the entire file. Current content describes a hair/wig e-commerce business with AR try-on. Rewrite to describe Style Eternal: a premium streetwear brand selling tees, hoodies, long sleeves, crewnecks, outerwear, bottoms, headwear, accessories. Drop-based release model. Flat pricing (no variant matrices). Collections: North Ward, Iron Bound, Love Never Dies, Essentials, Legacy, Graphics, Archive. Design system: dark palette (se-black #0A0A0A through se-bone #E8E4DE), gold accent #C4A35A, fonts Oswald/Inter/Space Grotesk.
>
> 8. **Fix `README.md`**: Has a merge conflict (<<<<<<< HEAD markers). Replace entire file with a clean README describing Style Eternal, the tech stack, quick start commands, and project structure.

---

## PR Title

```
fix: brand cleanup, email bug fix, SEO domain correction
```

## PR Description (copy-paste this)

```markdown
## Summary

Complete brand identity cleanup + critical bug fix. Removes all references to
"Eminence Hair Boutique" / `eminenceluxuryhair.com` and replaces with "Style Eternal"
/ `styleeternal.com` across the entire codebase.

## Critical Bug Fix

**`lib/email.js` line 254** — The concierge email template referenced `${attachmentLine}`
which is an undefined variable. The actual variable (defined on line 186) is `uploadsHtml`.
This would cause every concierge email send to silently fail or render "undefined" in the
email body. Fixed by replacing with `${uploadsHtml}`.

## Changes (11 files, 211 insertions, 285 deletions)

### `lib/email.js`
- Fix `${attachmentLine}` → `${uploadsHtml}` (critical bug)
- Update all `from:` addresses to `@styleeternal.com`
- Update all `reply_to:` addresses to `@styleeternal.com`
- Update default `to:` to `support@styleeternal.com`
- Update email body branding text

### `scripts/generate-static-seo.mjs`
- `SITE_NAME` → `"Style Eternal"`
- Default `SITE_URL` → `https://www.styleeternal.com`
- `DEFAULT_OG_IMAGE` → `se_og_banner.jpg`
- Complete rewrite of `staticRoutes` array: removed hair/wig routes, added streetwear category routes
- Complete rewrite of `COLLECTION_META` to match actual collections
- Updated all route descriptions to reference streetwear products

### `scripts/audit-products.mjs`
- Updated banner text from "Eminence Hair" to "Style Eternal"

### `.github/copilot-instructions.md`
- **Full rewrite.** Previous file described a hair/wig e-commerce business with AR try-on.
  Now accurately describes the Style Eternal streetwear stack, product categories, collections,
  design system, and coding conventions.

### `README.md`
- Resolved merge conflict (had `<<<<<<< HEAD` markers)
- Clean rewrite for Style Eternal

### `package.json`
- `"name": "eminence-hair"` → `"name": "style-eternal"`

### `tests/e2e/home.spec.js`
- Title assertion: `/Eminence/i` → `/Style Eternal/i`
- localStorage key: `eminence_referral` → `se_referral`

### `tests/e2e/checkout.spec.js`
- localStorage key: `eminence_referral` → `se_referral`

### `LAUNCH_CHECKLIST.md`, `OPTION_A_NOTES.md`, `REPO_MAP.md`
- Updated all Eminence Hair references to Style Eternal
- Updated domain references to styleeternal.com

## How to Verify

```bash
# Should return 0 results:
grep -rn "Eminence\|eminenceluxuryhair" --include="*.js" --include="*.jsx" \
  --include="*.mjs" --include="*.md" --include="*.json" --include="*.html" \
  | grep -v node_modules | grep -v ".git/" | grep -v package-lock
```

## Related

- Addresses brand contamination noted in website audit
- Prerequisite for DNS/domain cutover to styleeternal.com
- Should be merged before PR #2 and PR #3 (both currently Draft)
```
